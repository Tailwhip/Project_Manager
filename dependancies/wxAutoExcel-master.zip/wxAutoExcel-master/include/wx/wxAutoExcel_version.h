/////////////////////////////////////////////////////////////////////////////
// Author:      PB
// Modified by:
// Copyright:   (c) 2012 PB <pbfordev@gmail.com>
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////


#ifndef _WXAUTOEXCEL_VERSION_H
#define _WXAUTOEXCEL_VERSION_H

#define WXAUTOEXCEL_MAJOR_VERSION     1
#define WXAUTOEXCEL_MINOR_VERSION     0
#define WXAUTOEXCEL_RELEASE_NUMBER    0
#define WXAUTOEXCEL_SUBRELEASE_NUMBER 0
#define WXAUTOEXCEL_VERSION_STRING    "1.0.0.0"

#endif //#ifndef _WXAUTOEXCEL_VERSION_H
