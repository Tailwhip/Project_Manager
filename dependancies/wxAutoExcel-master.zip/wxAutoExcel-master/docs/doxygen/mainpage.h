/////////////////////////////////////////////////////////////////////////////
// Author:      PB
// Copyright:   (c) 2016 PB <pbfordev@gmail.com>
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////// 


/** @mainpage %wxAutoExcel Documentation
 
 
@li @subpage page_introduction
@li @subpage page_installation
@li @subpage page_tutorial
@li @subpage page_classes
@li @subpage page_FAQ
 
 **/